package com.example.ams.activity;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.ams.DetailActivity;
import com.example.ams.FragmentDashboard;
import com.example.ams.R;
import com.example.ams.activity.AssetList;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import org.eazegraph.lib.charts.PieChart;



public class Home extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private Toolbar mytoolbar;
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    static final int REQUEST_CODE=123;

    //    chart
    TextView tvPendingWork, tvStartedWorking, tvWorkInProgress, tvWorkreportsubmitted;
    PieChart pieChart;

    //    Session
    TextView TVSesstionDemo;

    FloatingActionButton btnAddItem;


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater=getMenuInflater();
        menuInflater.inflate(R.menu.my_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        Intent intent;
        switch (item.getItemId()){
            case R.id.item_camera:
                //Add Intents
                startActivity(new Intent(getApplicationContext(), com.example.ams.DetailActivity.class));
                return true;

            case R.id.item_userPro:
                //Add Intents
                startActivity(new Intent(getApplicationContext(), com.example.ams.DetailActivity.class));
                return true;


            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onBackPressed() {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setMessage("Are you sure you want to exit the app?")
                .setTitle("Alert")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Home.super.onBackPressed();
                        finish();
//                        System.exit(0);
                    }
                })
                .setNegativeButton("No.", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
        AlertDialog alertDialog=builder.create();
        alertDialog.show();
    }




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);



        SharedPreferences prefs=getSharedPreferences("prefs",MODE_PRIVATE);
        boolean firstStart=prefs.getBoolean("firstStart",true);
        if (firstStart){
            ShowStratDialog();
        }



        permisstion();

        drawerLayout=findViewById(R.id.drawerLayout_main_page);
        navigationView=findViewById(R.id.nav_menu_drawer);
        mytoolbar=(Toolbar)findViewById(R.id.myToolbar);
        btnAddItem=findViewById(R.id.AddItem);


        //Toolbar
        setSupportActionBar(mytoolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(true);
        getSupportActionBar().setTitle("AMS");

        //Navigation Drawer
        ActionBarDrawerToggle actionBarDrawerToggle=new ActionBarDrawerToggle(Home.this,
                drawerLayout,
                mytoolbar,
                R.string.open,
                R.string.close);
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();

        navigationView.setNavigationItemSelectedListener(this);
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                new FragmentDashboard()).commit();
        navigationView.setCheckedItem(R.id.nav_main_home);
    }




    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()){
            case R.id.nav_main_home:

                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                        new FragmentDashboard()).commit();
                break;

            case R.id.nav_main_beneficiary_list:
                //Add Intents
                startActivity(new Intent(getApplicationContext(), AssetList.class));
                break;
            case R.id.nav_main_AddNewBeneficiary:
                //Add Intents
                startActivity(new Intent(getApplicationContext(), com.example.ams.DetailActivity.class));
                break;
            case R.id.nav_main_QRCodeToBill:
                //Add Intents
                startActivity(new Intent(getApplicationContext(), com.example.ams.DetailActivity.class));

                break;

            case R.id.nav_main_contact:
                //Add Intents

                startActivity(new Intent(getApplicationContext(), DetailActivity.class));

                break;

            case R.id.nav_main_logout:

                break;

        }

        drawerLayout.closeDrawer(GravityCompat.START);
        return true;




    }


    public void permisstion(){
        //Permission Chacking
        if (ContextCompat.checkSelfPermission(Home.this, Manifest.permission.CAMERA)
                + ContextCompat.checkSelfPermission(Home.this, Manifest.permission.ACCESS_COARSE_LOCATION)
                + ContextCompat.checkSelfPermission(Home.this, Manifest.permission.ACCESS_FINE_LOCATION)    !=
                PackageManager.PERMISSION_GRANTED){

//                    When Permission Not grante
            if (ActivityCompat.shouldShowRequestPermissionRationale(Home.this,Manifest.permission.CAMERA)
                    || ActivityCompat.shouldShowRequestPermissionRationale(Home.this,Manifest.permission.ACCESS_COARSE_LOCATION)
                    || ActivityCompat.shouldShowRequestPermissionRationale(Home.this,Manifest.permission.ACCESS_FINE_LOCATION)
            )
            {
                AlertDialog.Builder builder=new AlertDialog.Builder(
                        Home.this
                );
                builder.setTitle("Grant those Permission");
                builder.setMessage("Camera,Read Contact");
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @RequiresApi(api = Build.VERSION_CODES.Q)
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        ActivityCompat.requestPermissions(
                                Home.this,new String[]{
                                        Manifest.permission.CAMERA,
                                        Manifest.permission.ACCESS_COARSE_LOCATION,
                                        Manifest.permission.ACCESS_FINE_LOCATION,
                                        Manifest.permission.ACCESS_BACKGROUND_LOCATION},
                                REQUEST_CODE
                        );
                    }
                });
                builder.setNegativeButton("Cancel",null);
                AlertDialog alertDialog=builder.create();
                alertDialog.show();
            }else {
                ActivityCompat.requestPermissions(
                        Home.this,new String[]{
                                Manifest.permission.CAMERA,
                                Manifest.permission.ACCESS_COARSE_LOCATION,
                                Manifest.permission.ACCESS_FINE_LOCATION
                        },
                        REQUEST_CODE
                );
            }
        }else {
//                    When Permisstion are alredy granted
//            Toast.makeText(getApplicationContext(),"Permisstion already granted",Toast.LENGTH_SHORT).show();
        }

    }

    private void ShowStratDialog(){

        new AlertDialog.Builder(this)
                .setTitle("Welcome To ZPFMS ")
                .setMessage("This should only be Show once")
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                }).create().show();

        SharedPreferences prefs=getSharedPreferences("prefs",MODE_PRIVATE);
        SharedPreferences.Editor editor=prefs.edit();
        editor.putBoolean("firstStart",false);
        editor.apply();
    }

    public void checkInternetConnection(){

    }
}
