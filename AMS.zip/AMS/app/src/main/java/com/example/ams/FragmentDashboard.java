package com.example.ams;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import org.eazegraph.lib.charts.PieChart;
import org.eazegraph.lib.models.PieModel;






public class FragmentDashboard extends Fragment {



    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;

    TextView tvPendingWork, tvStartedWorking, tvWorkInProgress, tvWorkreportsubmitted;
    PieChart pieChart;

    public FragmentDashboard() {
        // Required empty public constructor
    }

    public static FragmentDashboard newInstance(String param1, String param2) {
        FragmentDashboard fragment = new FragmentDashboard();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {



        View view=inflater.inflate(R.layout.fragment_dashboard, container, false);



        tvPendingWork = view.findViewById(R.id.tvPendingWork);
        tvStartedWorking = view.findViewById(R.id.tvStartedWorking);
        tvWorkInProgress = view.findViewById(R.id.tvWorkInProgress);
        tvWorkreportsubmitted = view.findViewById(R.id.tvWorkreportsubmitted);
        pieChart = view.findViewById(R.id.piechart);
        setData();


        return view;
    }

    //    Set Data For
    private void setData()
    {
        // Set the percentage of language used
        tvPendingWork.setText(Integer.toString(40));
        tvStartedWorking.setText(Integer.toString(25));
        tvWorkInProgress.setText(Integer.toString(10));
        tvWorkreportsubmitted.setText(Integer.toString(25));
        // Set the data and color to the pie chart
        pieChart.addPieSlice(
                new PieModel(
                        "Pending Work",
                        Integer.parseInt(tvPendingWork.getText().toString()),
                        Color.parseColor("#FFA726")));
        pieChart.addPieSlice(
                new PieModel(
                        "Started Working",
                        Integer.parseInt(tvStartedWorking.getText().toString()),
                        Color.parseColor("#66BB6A")));
        pieChart.addPieSlice(
                new PieModel(
                        "Work In Progress",
                        Integer.parseInt(tvWorkInProgress.getText().toString()),
                        Color.parseColor("#EF5350")));
        pieChart.addPieSlice(
                new PieModel(
                        "Work Report Submitted",
                        Integer.parseInt(tvWorkreportsubmitted.getText().toString()),
                        Color.parseColor("#29B6F6")));
        // To animate the pie chart
        pieChart.startAnimation();
    }

}